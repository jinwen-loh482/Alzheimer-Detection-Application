# Alzheimer-Detection-Application

We made our project with a localhost, so you are going to need to set up MAMP/Apache Server.
We did our project using Flask so you would have to run
"export FLASK_APP=app.py"
And then to run it, enter
"flask run"

You will also have to set up the database. There be an sql file inside the sql folder, and importing this folder inside phpMyAdmin would set up the database for you. 

